# ShoppingCart | .NET 7

## Before running:

1. dotnet restore
> to install packages
3. dotnet build
> to check that there is no errors

## To run:
- dotnet build
