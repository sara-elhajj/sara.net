﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ShoppingCart.Migrations
{
    /// <inheritdoc />
    public partial class addedRatingCountToProduct : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "RatingCount",
                table: "Products",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "admin-user",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "32da2bd6-a9a7-41b0-8ebb-b0f31ec4d410", "AQAAAAIAAYagAAAAEFGuHH4iKC56lsLnrIiF9q6NXWOxadWEYTQ1NHbo9r4uYjwfVKysrva4PcQik7rW9g==", "21247433-7a25-40c8-aa08-1ae8bd8dc951" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "RatingCount",
                table: "Products");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "admin-user",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "982fc799-e434-4693-969a-558c44ce29a6", "AQAAAAIAAYagAAAAEHl7nRP8r/ie0HZ1IQyW9F/e+99ZDEp0cMnBv2xPYnC6guBBFQRnF4jP8DElaFZgaA==", "9d2d6aab-8784-4889-9cfa-983e00c768b0" });
        }
    }
}
