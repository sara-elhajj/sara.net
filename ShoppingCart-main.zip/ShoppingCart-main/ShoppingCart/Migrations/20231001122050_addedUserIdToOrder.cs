﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ShoppingCart.Migrations
{
    /// <inheritdoc />
    public partial class addedUserIdToOrder : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "userId",
                table: "Orders",
                type: "TEXT",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "admin-user",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "74ddae16-458c-4157-908f-2c841b8dff84", "AQAAAAIAAYagAAAAEO8EHzxfjdKsynBBmu2DxBOjwMDb25Vx1qnwMy1ghefZvl0m643MgwtcoCUoa03Mew==", "457caf05-783d-4145-83cf-74bbedc4aae1" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "userId",
                table: "Orders");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "admin-user",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "150e1ad6-57c2-48dc-abe4-15fc138e236d", "AQAAAAIAAYagAAAAEBNtVK7WZhbPP7IofFk3LxHxUo8+UL40KLaRM5I6qWmkRvmmC9epOAJqRr8owfuFcQ==", "864e5af5-82f6-4c54-926d-d83e796cff7f" });
        }
    }
}
