﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ShoppingCart.Migrations
{
    /// <inheritdoc />
    public partial class addedRatingToProducts : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Rating",
                table: "Products",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "admin-user",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "982fc799-e434-4693-969a-558c44ce29a6", "AQAAAAIAAYagAAAAEHl7nRP8r/ie0HZ1IQyW9F/e+99ZDEp0cMnBv2xPYnC6guBBFQRnF4jP8DElaFZgaA==", "9d2d6aab-8784-4889-9cfa-983e00c768b0" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Rating",
                table: "Products");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "admin-user",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "74ddae16-458c-4157-908f-2c841b8dff84", "AQAAAAIAAYagAAAAEO8EHzxfjdKsynBBmu2DxBOjwMDb25Vx1qnwMy1ghefZvl0m643MgwtcoCUoa03Mew==", "457caf05-783d-4145-83cf-74bbedc4aae1" });
        }
    }
}
