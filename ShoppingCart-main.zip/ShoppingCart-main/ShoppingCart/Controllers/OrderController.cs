﻿using System.Security.Claims;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShoppingCart.Infrastructure;
using ShoppingCart.Models;
using ShoppingCart.Models.ViewModels;

namespace ShoppingCart.Controllers
{
    public class OrderController : Controller
    {
        private SignInManager<AppUser> _signInManager;
        private UserManager<AppUser> _userManager;

        private readonly DataContext _context;


        public OrderController(SignInManager<AppUser> signInManager, DataContext context,
            UserManager<AppUser> userManager)
        {
            _signInManager = signInManager;
            _context = context;
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            var userOrders = await _context.Orders.Where(o => o.userId == userId).Include(s => s.OrderItemsIds).ToListAsync();
            return View("Index", userOrders);
        }

        public async Task<IActionResult> Summary(string id)
        {
            var order = await _context.Orders.FirstOrDefaultAsync();
            var products = await _context.Orders.Where(o => o.Id.ToString().Equals(id)).Include(o => o.OrderItemsIds).ToListAsync();

            order.OrderItemsIds = products[0].OrderItemsIds;
            return View(order);
        }

    }
}