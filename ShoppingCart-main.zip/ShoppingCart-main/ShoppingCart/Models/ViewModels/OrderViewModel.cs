﻿namespace ShoppingCart.Models.ViewModels;

public class OrderViewModel
{
    public Order Order { get; set; }

    public CartViewModel CartViewModel { get; set; }
}