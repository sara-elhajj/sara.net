﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShoppingCart.Infrastructure;

namespace ShoppingCart.Areas.Admin.Controllers;

[Area("Admin")]
[Authorize(Roles = "Admin")]

public class RolesController : Controller
{
    private readonly DataContext _context;

    public RolesController(DataContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Index()
    {
        var roles = await _context.Roles.ToListAsync();
        return View(roles);
        
    }

}